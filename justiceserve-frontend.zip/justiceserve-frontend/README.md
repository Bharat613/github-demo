# JusticeServe Frontend

**Angular 20 · Bootstrap 5.3 · Full Legal Case Management System**

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Angular 20 (standalone components, lazy loading) |
| Styling | Bootstrap 5.3 + Bootstrap Icons 1.11 |
| HTTP | Angular HttpClient with JWT interceptor |
| Routing | Angular Router with lazy-loaded modules |
| State | BehaviorSubject (Auth), local component state |
| Backend | Spring Boot 3.2.5 on `http://localhost:8080` |

---

## Prerequisites

| Tool | Version | Install |
|---|---|---|
| Node.js | ≥ 18.x | https://nodejs.org |
| npm | ≥ 9.x | bundled with Node |
| Angular CLI | ^20.0.0 | `npm install -g @angular/cli@20` |

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
ng serve

# 3. Open browser
http://localhost:4200
```

> **Backend must be running** at `http://localhost:8080`
> See `justiceserve-backend` project for Spring Boot setup.

---

## Project Structure

```
src/
├── app/
│   ├── app.component.ts        ← Root component
│   ├── app.config.ts           ← App-level providers (HttpClient, Router)
│   ├── app.routes.ts           ← Top-level routes with lazy loading
│   │
│   ├── core/
│   │   ├── guards/
│   │   │   └── auth.guard.ts   ← authGuard, guestGuard
│   │   ├── interceptors/
│   │   │   └── jwt.interceptor.ts  ← Attaches Bearer token to every request
│   │   └── services/
│   │       ├── auth.service.ts     ← Login, register, logout, currentUser
│   │       └── api.service.ts      ← All backend API calls (one file)
│   │
│   ├── shared/
│   │   ├── models/
│   │   │   └── models.ts       ← All TypeScript interfaces matching backend DTOs
│   │   └── components/
│   │       └── layout.component.ts ← Sidebar + topbar shell
│   │
│   └── modules/
│       ├── auth/               ← Login & Register pages
│       ├── dashboard/          ← Stats + recent cases/hearings
│       ├── citizens/           ← List, create, detail, documents
│       ├── cases/              ← List, file, detail, documents
│       ├── hearings/           ← List, schedule, detail, proceedings
│       ├── judgments/          ← List, record, finalize, court orders
│       ├── compliance/         ← Compliance records + audits (tabbed)
│       ├── reports/            ← Generate & view analytics reports
│       ├── notifications/      ← Notification inbox with mark-read
│       └── users/              ← Admin user management
│
├── environments/
│   ├── environment.ts          ← Dev: apiUrl = http://localhost:8080/api
│   └── environment.prod.ts     ← Prod: update apiUrl here
└── styles.scss                 ← Global Bootstrap + custom CSS
```

---

## Backend API Mapping

Every frontend service call maps directly to a backend endpoint:

### Auth
| UI Action | API Call |
|---|---|
| Login form submit | `POST /api/auth/login` |
| Register form submit | `POST /api/auth/register` |

### Users (Admin)
| UI Action | API Call |
|---|---|
| View all users | `GET /api/users` |
| Filter by role | `GET /api/users/role/{role}` |
| Activate/Deactivate | `PATCH /api/users/{id}/status?status=` |
| Delete user | `DELETE /api/users/{id}` |

### Citizens
| UI Action | API Call |
|---|---|
| List all citizens | `GET /api/citizens` |
| Register citizen | `POST /api/citizens` |
| View profile | `GET /api/citizens/{id}` |
| Upload document | `POST /api/citizens/{id}/documents` |
| Verify document | `PATCH /api/citizens/{id}/documents/{dId}/verify` |

### Cases
| UI Action | API Call |
|---|---|
| List all cases | `GET /api/cases` |
| File new case | `POST /api/cases` |
| View case detail | `GET /api/cases/{id}` |
| Update status | `PATCH /api/cases/{id}/status?status=` |
| Upload document | `POST /api/cases/{id}/documents` |
| Verify document | `PATCH /api/cases/{id}/documents/{dId}/verify` |

### Hearings
| UI Action | API Call |
|---|---|
| List all hearings | `GET /api/hearings` |
| Schedule hearing | `POST /api/hearings` |
| View hearing detail | `GET /api/hearings/{id}` |
| Update status | `PATCH /api/hearings/{id}/status?status=` |
| Add proceeding | `POST /api/hearings/{id}/proceedings` |

### Judgments
| UI Action | API Call |
|---|---|
| List judgments | `GET /api/judgments` |
| Record judgment | `POST /api/judgments` |
| Finalize judgment | `PATCH /api/judgments/{id}/finalize` |
| Issue court order | `POST /api/court-orders` |
| Update order status | `PATCH /api/court-orders/{id}/status?status=` |

### Compliance & Audits
| UI Action | API Call |
|---|---|
| List compliance records | `GET /api/compliance` |
| Create compliance record | `POST /api/compliance` |
| Update compliance record | `PATCH /api/compliance/{id}` |
| List audits | `GET /api/audits` |
| Create audit | `POST /api/audits` |
| Update audit status | `PATCH /api/audits/{id}/status?status=` |

### Reports
| UI Action | API Call |
|---|---|
| Generate report | `POST /api/reports/generate` |
| List all reports | `GET /api/reports` |

### Notifications
| UI Action | API Call |
|---|---|
| Load notifications | `GET /api/notifications/user/{id}` |
| Mark as read | `PATCH /api/notifications/{id}/read` |
| Bell badge count | `GET /api/notifications/user/{id}/unread-count` (polls every 30s) |

---

## Authentication Flow

1. User submits login → `POST /api/auth/login`
2. Response: `{ token, userId, name, email, role }`
3. Token stored in `localStorage` as `js_token`
4. `JwtInterceptor` attaches `Authorization: Bearer <token>` to all requests
5. On 401 response → auto-logout + redirect to `/auth/login`
6. `AuthGuard` protects all routes under `/dashboard`, `/cases`, etc.

---

## Role-Based UI

| Role | Dashboard | Citizens | Cases | Hearings | Judgments | Compliance | Reports | Admin |
|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| ADMIN | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| JUDGE | ✓ | ✓ | ✓ | ✓ | ✓ | — | ✓ | — |
| CLERK | ✓ | ✓ | ✓ | ✓ | — | — | — | — |
| LAWYER | ✓ | ✓ | ✓ | ✓ | — | — | — | — |
| CITIZEN | ✓ | — | ✓ | — | — | — | — | — |
| COMPLIANCE | ✓ | — | — | — | — | ✓ | ✓ | — |
| AUDITOR | ✓ | — | — | — | — | ✓ | ✓ | — |

---

## CORS Configuration

Backend is configured for `http://localhost:4200` (Angular dev server).

To change the backend URL, edit:
```typescript
// src/environments/environment.ts
export const environment = {
  production: false,
  apiUrl: 'http://YOUR_BACKEND:8080/api'
};
```

---

## Build for Production

```bash
ng build --configuration production
```

Output goes to `dist/justiceserve-frontend/browser/`.

Deploy the contents of that folder to any static web server (Nginx, Apache, etc).

---

## Troubleshooting

| Problem | Solution |
|---|---|
| `CORS error` | Ensure backend is running and CORS allows `localhost:4200` |
| `401 Unauthorized` | Token expired — log out and log in again |
| `Network Error` | Check backend is running: `http://localhost:8080/swagger-ui.html` |
| `ng: command not found` | Run `npm install -g @angular/cli@20` |
| White screen after login | Check browser console for errors, verify backend is running |

---

## Default Test Credentials

Register accounts through `/auth/register` with these roles:

```
admin@justiceserve.com    / admin123   → ADMIN
judge@justiceserve.com    / judge123   → JUDGE  
clerk@justiceserve.com    / clerk123   → CLERK
lawyer@justiceserve.com   / law123     → LAWYER
citizen@justiceserve.com  / cit123     → CITIZEN
```
