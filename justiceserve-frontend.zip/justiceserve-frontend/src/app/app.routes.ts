import { Routes } from '@angular/router';
import { authGuard, guestGuard } from './core/guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  {
    path: 'auth',
    canActivate: [guestGuard],
    loadChildren: () => import('./modules/auth/auth.routes').then(m => m.authRoutes)
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () => import('./shared/components/layout.component').then(m => m.LayoutComponent),
    children: [
      { path: 'dashboard', loadComponent: () => import('./modules/dashboard/dashboard.component').then(m => m.DashboardComponent) },
      { path: 'users', loadChildren: () => import('./modules/users/users.routes').then(m => m.usersRoutes) },
      { path: 'citizens', loadChildren: () => import('./modules/citizens/citizens.routes').then(m => m.citizensRoutes) },
      { path: 'cases', loadChildren: () => import('./modules/cases/cases.routes').then(m => m.casesRoutes) },
      { path: 'hearings', loadChildren: () => import('./modules/hearings/hearings.routes').then(m => m.hearingsRoutes) },
      { path: 'judgments', loadChildren: () => import('./modules/judgments/judgments.routes').then(m => m.judgmentsRoutes) },
      { path: 'compliance', loadChildren: () => import('./modules/compliance/compliance.routes').then(m => m.complianceRoutes) },
      { path: 'reports', loadChildren: () => import('./modules/reports/reports.routes').then(m => m.reportsRoutes) },
      { path: 'notifications', loadComponent: () => import('./modules/notifications/notifications.component').then(m => m.NotificationsComponent) },
    ]
  },
  { path: '**', redirectTo: 'dashboard' }
];
