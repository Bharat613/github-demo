import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="min-vh-100 d-flex align-items-center justify-content-center"
         style="background: linear-gradient(135deg, #1a3a5c 0%, #2e6da4 100%)">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-6">
            <div class="text-center mb-4">
              <i class="bi bi-balance-scale text-warning" style="font-size:3rem"></i>
              <h2 class="text-white mt-2 fw-bold">JusticeServe</h2>
            </div>
            <div class="card">
              <div class="card-body p-4">
                <h5 class="fw-bold mb-4">Create Account</h5>
                <div *ngIf="error" class="alert alert-danger py-2">{{ error }}</div>
                <div *ngIf="success" class="alert alert-success py-2">{{ success }}</div>
                <form (ngSubmit)="onSubmit()">
                  <div class="row g-3">
                    <div class="col-md-6">
                      <label class="form-label">Full Name</label>
                      <input type="text" class="form-control" [(ngModel)]="form.name" name="name" required placeholder="John Doe">
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Role</label>
                      <select class="form-select" [(ngModel)]="form.role" name="role" required>
                        <option value="">Select role</option>
                        <option value="CITIZEN">Citizen</option>
                        <option value="LAWYER">Lawyer</option>
                        <option value="JUDGE">Judge</option>
                        <option value="CLERK">Court Clerk</option>
                        <option value="COMPLIANCE">Compliance Officer</option>
                        <option value="AUDITOR">Government Auditor</option>
                      </select>
                    </div>
                    <div class="col-12">
                      <label class="form-label">Email</label>
                      <input type="email" class="form-control" [(ngModel)]="form.email" name="email" required placeholder="email@example.com">
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Password</label>
                      <input type="password" class="form-control" [(ngModel)]="form.password" name="password" required placeholder="••••••••">
                    </div>
                    <div class="col-md-6">
                      <label class="form-label">Phone</label>
                      <input type="text" class="form-control" [(ngModel)]="form.phone" name="phone" placeholder="+91 9999999999">
                    </div>
                    <div class="col-12">
                      <button type="submit" class="btn btn-primary w-100" [disabled]="loading">
                        <span *ngIf="loading" class="spinner-border spinner-border-sm me-2"></span>
                        {{ loading ? 'Creating...' : 'Create Account' }}
                      </button>
                    </div>
                  </div>
                </form>
                <p class="text-center mt-3 mb-0 text-muted" style="font-size:0.88rem">
                  Already have an account? <a routerLink="/auth/login">Sign In</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RegisterComponent {
  form = { name: '', email: '', password: '', role: '', phone: '' };
  loading = false;
  error = '';
  success = '';

  constructor(private auth: AuthService, private router: Router) {}

  onSubmit(): void {
    this.loading = true;
    this.error = '';
    this.auth.register(this.form).subscribe({
      next: () => { this.success = 'Account created! Redirecting...'; setTimeout(() => this.router.navigate(['/dashboard']), 1000); },
      error: (e) => { this.error = e.error?.message || 'Registration failed'; this.loading = false; }
    });
  }
}
