import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';
import { CaseApiService, HearingApiService, JudgmentApiService, CitizenApiService } from '../../core/services/api.service';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, RouterLink],
  template: `
    <div class="page-header d-flex align-items-center justify-content-between">
      <div>
        <h4><i class="bi bi-grid me-2"></i>Dashboard</h4>
        <p class="text-muted mb-0" style="font-size:0.85rem">Welcome back, {{ userName }}</p>
      </div>
    </div>

    <div class="p-4">
      <!-- Stat Cards -->
      <div class="row g-3 mb-4">
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#667eea,#764ba2)">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div style="font-size:0.8rem;opacity:0.8">Total Cases</div>
                <div style="font-size:2rem;font-weight:700">{{ stats.totalCases }}</div>
              </div>
              <i class="bi bi-folder2-open" style="font-size:2.5rem;opacity:0.5"></i>
            </div>
            <a routerLink="/cases" class="text-white-50 text-decoration-none" style="font-size:0.8rem">View all →</a>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#f093fb,#f5576c)">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div style="font-size:0.8rem;opacity:0.8">Active Cases</div>
                <div style="font-size:2rem;font-weight:700">{{ stats.activeCases }}</div>
              </div>
              <i class="bi bi-activity" style="font-size:2.5rem;opacity:0.5"></i>
            </div>
            <a routerLink="/cases" class="text-white-50 text-decoration-none" style="font-size:0.8rem">View active →</a>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#4facfe,#00f2fe)">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div style="font-size:0.8rem;opacity:0.8">Hearings</div>
                <div style="font-size:2rem;font-weight:700">{{ stats.totalHearings }}</div>
              </div>
              <i class="bi bi-calendar-event" style="font-size:2.5rem;opacity:0.5"></i>
            </div>
            <a routerLink="/hearings" class="text-white-50 text-decoration-none" style="font-size:0.8rem">View all →</a>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="stat-card" style="background:linear-gradient(135deg,#43e97b,#38f9d7)">
            <div class="d-flex justify-content-between align-items-center">
              <div>
                <div style="font-size:0.8rem;opacity:0.8">Citizens</div>
                <div style="font-size:2rem;font-weight:700">{{ stats.totalCitizens }}</div>
              </div>
              <i class="bi bi-people" style="font-size:2.5rem;opacity:0.5"></i>
            </div>
            <a routerLink="/citizens" class="text-white-50 text-decoration-none" style="font-size:0.8rem">View all →</a>
          </div>
        </div>
      </div>

      <!-- Recent Cases + Quick Actions -->
      <div class="row g-3">
        <div class="col-lg-8">
          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
              <span><i class="bi bi-folder2-open me-2"></i>Recent Cases</span>
              <a routerLink="/cases" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
              <div *ngIf="loading" class="text-center py-4">
                <div class="spinner-border text-primary"></div>
              </div>
              <div class="table-responsive" *ngIf="!loading">
                <table class="table table-hover mb-0">
                  <thead><tr>
                    <th>ID</th><th>Title</th><th>Citizen</th><th>Filed</th><th>Status</th>
                  </tr></thead>
                  <tbody>
                    <tr *ngFor="let c of recentCases">
                      <td>#{{ c.caseId }}</td>
                      <td><a [routerLink]="['/cases', c.caseId]">{{ c.title }}</a></td>
                      <td>{{ c.citizenName }}</td>
                      <td>{{ c.filedDate | date:'mediumDate' }}</td>
                      <td><span class="badge" [ngClass]="statusBadge(c.status)">{{ c.status }}</span></td>
                    </tr>
                    <tr *ngIf="recentCases.length === 0">
                      <td colspan="5" class="text-center text-muted py-3">No cases found</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="card h-100">
            <div class="card-header"><i class="bi bi-lightning me-2"></i>Quick Actions</div>
            <div class="card-body d-flex flex-column gap-2">
              <a routerLink="/cases/new" class="btn btn-outline-primary d-flex align-items-center gap-2">
                <i class="bi bi-folder-plus"></i> File New Case
              </a>
              <a routerLink="/citizens/new" class="btn btn-outline-success d-flex align-items-center gap-2">
                <i class="bi bi-person-plus"></i> Register Citizen
              </a>
              <a routerLink="/hearings/new" class="btn btn-outline-info d-flex align-items-center gap-2">
                <i class="bi bi-calendar-plus"></i> Schedule Hearing
              </a>
              <a routerLink="/judgments/new" class="btn btn-outline-warning d-flex align-items-center gap-2">
                <i class="bi bi-hammer"></i> Record Judgment
              </a>
              <a routerLink="/reports" class="btn btn-outline-secondary d-flex align-items-center gap-2">
                <i class="bi bi-bar-chart"></i> Generate Report
              </a>
            </div>
          </div>
        </div>
      </div>

      <!-- Recent Hearings -->
      <div class="row g-3 mt-1">
        <div class="col-12">
          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
              <span><i class="bi bi-calendar-event me-2"></i>Upcoming Hearings</span>
              <a routerLink="/hearings" class="btn btn-sm btn-outline-primary">View All</a>
            </div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-hover mb-0">
                  <thead><tr>
                    <th>ID</th><th>Case</th><th>Judge</th><th>Date</th><th>Time</th><th>Status</th>
                  </tr></thead>
                  <tbody>
                    <tr *ngFor="let h of recentHearings">
                      <td>#{{ h.hearingId }}</td>
                      <td>{{ h.caseTitle }}</td>
                      <td>{{ h.judgeName }}</td>
                      <td>{{ h.date | date:'mediumDate' }}</td>
                      <td>{{ h.time }}</td>
                      <td><span class="badge" [ngClass]="statusBadge(h.status)">{{ h.status }}</span></td>
                    </tr>
                    <tr *ngIf="recentHearings.length === 0">
                      <td colspan="6" class="text-center text-muted py-3">No hearings scheduled</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DashboardComponent implements OnInit {
  loading = true;
  stats = { totalCases: 0, activeCases: 0, totalHearings: 0, totalCitizens: 0 };
  recentCases: any[] = [];
  recentHearings: any[] = [];

  constructor(
    private caseApi: CaseApiService,
    private hearingApi: HearingApiService,
    private citizenApi: CitizenApiService,
    private auth: AuthService
  ) {}

  get userName(): string { return this.auth.currentUser?.name ?? ''; }

  ngOnInit(): void {
    forkJoin({
      cases: this.caseApi.getAll(),
      hearings: this.hearingApi.getAll(),
      citizens: this.citizenApi.getAll()
    }).subscribe({
      next: ({ cases, hearings, citizens }) => {
        this.stats.totalCases = cases.length;
        this.stats.activeCases = cases.filter(c => c.status === 'ACTIVE').length;
        this.stats.totalHearings = hearings.length;
        this.stats.totalCitizens = citizens.length;
        this.recentCases = cases.slice(-5).reverse();
        this.recentHearings = hearings.slice(-5).reverse();
        this.loading = false;
      },
      error: () => { this.loading = false; }
    });
  }

  statusBadge(status: string): string {
    const map: Record<string, string> = {
      FILED: 'bg-secondary', ACTIVE: 'bg-success', CLOSED: 'bg-dark',
      UNDER_REVIEW: 'bg-warning text-dark', HEARING_SCHEDULED: 'bg-info text-dark',
      JUDGMENT_PENDING: 'bg-danger', DISMISSED: 'bg-secondary',
      SCHEDULED: 'bg-primary', COMPLETED: 'bg-success', ADJOURNED: 'bg-warning text-dark',
      CANCELLED: 'bg-danger', IN_PROGRESS: 'bg-info text-dark',
      DRAFT: 'bg-warning text-dark', FINAL: 'bg-success'
    };
    return map[status] ?? 'bg-secondary';
  }
}
