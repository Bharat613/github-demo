import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ReportApiService } from '../../core/services/api.service';
import { ReportResponse } from '../../shared/models/models';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-header">
      <h4><i class="bi bi-bar-chart me-2"></i>Analytics & Reports</h4>
    </div>
    <div class="p-4">
      <!-- Generate Report -->
      <div class="card mb-4">
        <div class="card-header">Generate New Report</div>
        <div class="card-body">
          <div class="row g-3 align-items-end">
            <div class="col-md-4">
              <label class="form-label">Report Scope</label>
              <select class="form-select" [(ngModel)]="scope">
                <option value="">Select scope...</option>
                <option value="CASE">Cases</option>
                <option value="HEARING">Hearings</option>
                <option value="JUDGMENT">Judgments</option>
                <option value="COMPLIANCE">Compliance</option>
              </select>
            </div>
            <div class="col-md-2">
              <button class="btn btn-primary w-100" (click)="generate()" [disabled]="!scope || generating">
                <span *ngIf="generating" class="spinner-border spinner-border-sm me-1"></span>
                Generate
              </button>
            </div>
          </div>
          <div *ngIf="generated" class="mt-3">
            <div class="alert alert-success">
              <strong>Report #{{ generated.reportId }} Generated!</strong><br>
              Scope: {{ generated.scope }}<br>
              <code>{{ generated.metrics }}</code>
            </div>
          </div>
        </div>
      </div>

      <!-- Metric Cards for Latest Report -->
      <div *ngIf="generated && parsedMetrics" class="row g-3 mb-4">
        <div class="col-sm-6 col-md-3" *ngFor="let m of metricEntries">
          <div class="card text-center p-3">
            <div class="text-muted" style="font-size:0.8rem;text-transform:uppercase">{{ m.key }}</div>
            <div class="fw-bold" style="font-size:2rem;color:var(--js-secondary)">{{ m.value }}</div>
          </div>
        </div>
      </div>

      <!-- All Reports -->
      <div class="card">
        <div class="card-header">All Reports</div>
        <div class="card-body p-0">
          <div *ngIf="loading" class="text-center py-4"><div class="spinner-border text-primary"></div></div>
          <table class="table table-hover mb-0" *ngIf="!loading">
            <thead><tr><th>ID</th><th>Scope</th><th>Generated On</th><th>Metrics</th></tr></thead>
            <tbody>
              <tr *ngFor="let r of reports">
                <td>#{{ r.reportId }}</td>
                <td><span class="badge bg-info text-dark">{{ r.scope }}</span></td>
                <td>{{ r.generatedDate | date:'medium' }}</td>
                <td><code style="font-size:0.75rem">{{ r.metrics }}</code></td>
              </tr>
              <tr *ngIf="reports.length===0"><td colspan="4" class="text-center text-muted py-3">No reports yet</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class ReportsComponent implements OnInit {
  reports: ReportResponse[] = [];
  loading = true;
  scope = '';
  generating = false;
  generated: ReportResponse | null = null;
  parsedMetrics: Record<string,any> | null = null;

  constructor(private api: ReportApiService, private auth: AuthService) {}

  get metricEntries(): { key: string, value: any }[] {
    if (!this.parsedMetrics) return [];
    return Object.entries(this.parsedMetrics).map(([key, value]) => ({ key, value }));
  }

  ngOnInit(): void {
    this.api.getAll().subscribe({ next: d => { this.reports = d; this.loading = false; }, error: () => this.loading = false });
  }

  generate(): void {
    this.generating = true;
    const userId = this.auth.currentUser?.userId ?? 1;
    this.api.generate({ scope: this.scope, generatedBy: userId }).subscribe({
      next: r => {
        this.generated = r;
        try { this.parsedMetrics = JSON.parse(r.metrics); } catch { this.parsedMetrics = null; }
        this.reports = [r, ...this.reports];
        this.generating = false;
      },
      error: () => this.generating = false
    });
  }
}
