import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CaseApiService } from '../../core/services/api.service';
import { CaseResponse } from '../../shared/models/models';

@Component({
  selector: 'app-cases-list',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule],
  template: `
    <div class="page-header d-flex align-items-center justify-content-between">
      <h4><i class="bi bi-folder2-open me-2"></i>Cases</h4>
      <a routerLink="/cases/new" class="btn btn-primary"><i class="bi bi-plus me-1"></i>File New Case</a>
    </div>
    <div class="p-4">
      <!-- Filter bar -->
      <div class="card mb-3">
        <div class="card-body py-2">
          <div class="row g-2 align-items-center">
            <div class="col-md-4">
              <input class="form-control form-control-sm" placeholder="Search by title or citizen..."
                     [(ngModel)]="searchTerm">
            </div>
            <div class="col-md-3">
              <select class="form-select form-select-sm" [(ngModel)]="filterStatus" (change)="applyFilter()">
                <option value="">All Statuses</option>
                <option *ngFor="let s of statuses" [value]="s">{{ s }}</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-body p-0">
          <div *ngIf="loading" class="text-center py-5"><div class="spinner-border text-primary"></div></div>
          <div class="table-responsive" *ngIf="!loading">
            <table class="table table-hover mb-0">
              <thead><tr>
                <th>Case ID</th><th>Title</th><th>Citizen</th><th>Lawyer</th>
                <th>Filed Date</th><th>Status</th><th>Actions</th>
              </tr></thead>
              <tbody>
                <tr *ngFor="let c of filtered">
                  <td><strong>#{{ c.caseId }}</strong></td>
                  <td>{{ c.title }}</td>
                  <td>{{ c.citizenName }}</td>
                  <td>{{ c.lawyerName || '—' }}</td>
                  <td>{{ c.filedDate | date:'mediumDate' }}</td>
                  <td><span class="badge" [ngClass]="badge(c.status)">{{ c.status }}</span></td>
                  <td>
                    <a [routerLink]="['/cases', c.caseId]" class="btn btn-sm btn-outline-primary">
                      <i class="bi bi-eye"></i>
                    </a>
                  </td>
                </tr>
                <tr *ngIf="filtered.length === 0">
                  <td colspan="7" class="text-center text-muted py-4">No cases found</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CasesListComponent implements OnInit {
  cases: CaseResponse[] = [];
  filtered: CaseResponse[] = [];
  loading = true;
  searchTerm = '';
  filterStatus = '';
  statuses = ['FILED','UNDER_REVIEW','ACTIVE','HEARING_SCHEDULED','JUDGMENT_PENDING','CLOSED','DISMISSED'];

  constructor(private api: CaseApiService) {}

  ngOnInit(): void {
    this.api.getAll().subscribe({ next: d => { this.cases = d; this.applyFilter(); this.loading = false; }, error: () => this.loading = false });
  }

  applyFilter(): void {
    this.filtered = this.cases.filter(c =>
      (!this.filterStatus || c.status === this.filterStatus) &&
      (!this.searchTerm || c.title.toLowerCase().includes(this.searchTerm.toLowerCase()) || c.citizenName?.toLowerCase().includes(this.searchTerm.toLowerCase()))
    );
  }

  badge(s: string): string {
    const m: Record<string,string> = { FILED:'bg-secondary', ACTIVE:'bg-success', CLOSED:'bg-dark', UNDER_REVIEW:'bg-warning text-dark', HEARING_SCHEDULED:'bg-info text-dark', JUDGMENT_PENDING:'bg-danger', DISMISSED:'bg-secondary' };
    return m[s] ?? 'bg-secondary';
  }
}
