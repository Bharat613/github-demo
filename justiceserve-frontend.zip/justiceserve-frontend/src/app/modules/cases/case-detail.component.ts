import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { CaseApiService, HearingApiService, JudgmentApiService } from '../../core/services/api.service';
import { CaseResponse, DocumentResponse, HearingResponse, JudgmentResponse } from '../../shared/models/models';

@Component({
  selector: 'app-case-detail',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-header d-flex justify-content-between align-items-center">
      <div>
        <h4><i class="bi bi-folder2-open me-2"></i>Case Details</h4>
        <small class="text-muted">Case #{{ caseId }}</small>
      </div>
      <a routerLink="/cases" class="btn btn-outline-secondary btn-sm"><i class="bi bi-arrow-left me-1"></i>Back</a>
    </div>

    <div class="p-4" *ngIf="!loading && case">
      <!-- Case Info -->
      <div class="row g-3 mb-4">
        <div class="col-lg-8">
          <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
              <span>{{ case.title }}</span>
              <span class="badge fs-6" [ngClass]="badge(case.status)">{{ case.status }}</span>
            </div>
            <div class="card-body">
              <div class="row g-3">
                <div class="col-sm-6">
                  <small class="text-muted d-block">Citizen</small>
                  <strong>{{ case.citizenName }}</strong>
                </div>
                <div class="col-sm-6">
                  <small class="text-muted d-block">Lawyer</small>
                  <strong>{{ case.lawyerName || 'Not assigned' }}</strong>
                </div>
                <div class="col-sm-6">
                  <small class="text-muted d-block">Filed Date</small>
                  <strong>{{ case.filedDate | date:'longDate' }}</strong>
                </div>
                <div class="col-12">
                  <small class="text-muted d-block">Description</small>
                  <p class="mb-0">{{ case.description || 'No description provided.' }}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="card">
            <div class="card-header">Update Status</div>
            <div class="card-body">
              <select class="form-select mb-2" [(ngModel)]="newStatus">
                <option *ngFor="let s of statuses" [value]="s">{{ s }}</option>
              </select>
              <button class="btn btn-primary w-100" (click)="updateStatus()">Update</button>
              <div *ngIf="statusMsg" class="alert alert-success mt-2 py-1 text-center">{{ statusMsg }}</div>
            </div>
          </div>
        </div>
      </div>

      <!-- Documents -->
      <div class="card mb-3">
        <div class="card-header d-flex justify-content-between">
          <span><i class="bi bi-file-earmark me-2"></i>Documents</span>
          <button class="btn btn-sm btn-outline-primary" (click)="showDocForm=!showDocForm">+ Add Document</button>
        </div>
        <div *ngIf="showDocForm" class="card-body border-bottom bg-light">
          <div class="row g-2">
            <div class="col-md-4">
              <select class="form-select form-select-sm" [(ngModel)]="docForm.docType">
                <option value="">Doc Type...</option>
                <option *ngFor="let t of docTypes" [value]="t">{{ t }}</option>
              </select>
            </div>
            <div class="col-md-6">
              <input class="form-control form-control-sm" [(ngModel)]="docForm.fileUri" placeholder="File URI/path">
            </div>
            <div class="col-md-2">
              <button class="btn btn-sm btn-success w-100" (click)="addDocument()">Add</button>
            </div>
          </div>
        </div>
        <div class="card-body p-0">
          <table class="table table-sm mb-0">
            <thead><tr><th>Type</th><th>File</th><th>Uploaded</th><th>Status</th><th>Action</th></tr></thead>
            <tbody>
              <tr *ngFor="let d of documents">
                <td>{{ d.docType }}</td>
                <td><a [href]="d.fileUri" target="_blank">{{ d.fileUri }}</a></td>
                <td>{{ d.uploadedDate | date:'mediumDate' }}</td>
                <td><span class="badge" [ngClass]="verifyBadge(d.verificationStatus)">{{ d.verificationStatus }}</span></td>
                <td>
                  <button class="btn btn-xs btn-sm btn-outline-success me-1" (click)="verifyDoc(d.documentId,'VERIFIED')">✓</button>
                  <button class="btn btn-xs btn-sm btn-outline-danger" (click)="verifyDoc(d.documentId,'REJECTED')">✗</button>
                </td>
              </tr>
              <tr *ngIf="documents.length===0"><td colspan="5" class="text-muted text-center py-2">No documents</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Hearings -->
      <div class="card mb-3">
        <div class="card-header"><i class="bi bi-calendar-event me-2"></i>Hearings</div>
        <div class="card-body p-0">
          <table class="table table-sm mb-0">
            <thead><tr><th>ID</th><th>Judge</th><th>Date</th><th>Time</th><th>Status</th></tr></thead>
            <tbody>
              <tr *ngFor="let h of hearings">
                <td>#{{ h.hearingId }}</td>
                <td>{{ h.judgeName }}</td>
                <td>{{ h.date | date:'mediumDate' }}</td>
                <td>{{ h.time }}</td>
                <td><span class="badge" [ngClass]="badge(h.status)">{{ h.status }}</span></td>
              </tr>
              <tr *ngIf="hearings.length===0"><td colspan="5" class="text-muted text-center py-2">No hearings</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Judgments -->
      <div class="card">
        <div class="card-header"><i class="bi bi-hammer me-2"></i>Judgments</div>
        <div class="card-body p-0">
          <table class="table table-sm mb-0">
            <thead><tr><th>ID</th><th>Judge</th><th>Summary</th><th>Date</th><th>Status</th></tr></thead>
            <tbody>
              <tr *ngFor="let j of judgments">
                <td>#{{ j.judgmentId }}</td>
                <td>{{ j.judgeName }}</td>
                <td>{{ j.summary | slice:0:60 }}...</td>
                <td>{{ j.date | date:'mediumDate' }}</td>
                <td><span class="badge" [ngClass]="badge(j.status)">{{ j.status }}</span></td>
              </tr>
              <tr *ngIf="judgments.length===0"><td colspan="5" class="text-muted text-center py-2">No judgments</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <div *ngIf="loading" class="text-center py-5"><div class="spinner-border text-primary"></div></div>
  `
})
export class CaseDetailComponent implements OnInit {
  caseId!: number;
  case!: CaseResponse;
  documents: DocumentResponse[] = [];
  hearings: HearingResponse[] = [];
  judgments: JudgmentResponse[] = [];
  loading = true;
  newStatus = '';
  statusMsg = '';
  showDocForm = false;
  docForm = { docType: '', fileUri: '' };
  statuses = ['FILED','UNDER_REVIEW','ACTIVE','HEARING_SCHEDULED','JUDGMENT_PENDING','CLOSED','DISMISSED'];
  docTypes = ['PETITION','EVIDENCE','ORDER','ID_PROOF','LEGAL_DOC'];

  constructor(private route: ActivatedRoute, private api: CaseApiService, private hearingApi: HearingApiService, private judgmentApi: JudgmentApiService) {}

  ngOnInit(): void {
    this.caseId = +this.route.snapshot.params['id'];
    this.load();
  }

  load(): void {
    this.api.getById(this.caseId).subscribe(c => {
      this.case = c; this.newStatus = c.status; this.loading = false;
    });
    this.api.getDocuments(this.caseId).subscribe(d => this.documents = d);
    this.hearingApi.getByCase(this.caseId).subscribe(h => this.hearings = h);
    this.judgmentApi.getByCase(this.caseId).subscribe(j => this.judgments = j);
  }

  updateStatus(): void {
    this.api.updateStatus(this.caseId, this.newStatus).subscribe(c => {
      this.case = c; this.statusMsg = 'Status updated!'; setTimeout(() => this.statusMsg = '', 2000);
    });
  }

  addDocument(): void {
    if (!this.docForm.docType || !this.docForm.fileUri) return;
    this.api.addDocument(this.caseId, this.docForm as any).subscribe(d => {
      this.documents = [...this.documents, d]; this.showDocForm = false; this.docForm = { docType: '', fileUri: '' };
    });
  }

  verifyDoc(docId: number, status: string): void {
    this.api.verifyDocument(this.caseId, docId, status).subscribe(d => {
      this.documents = this.documents.map(x => x.documentId === docId ? d : x);
    });
  }

  badge(s: string): string {
    const m: Record<string,string> = { FILED:'bg-secondary', ACTIVE:'bg-success', CLOSED:'bg-dark', UNDER_REVIEW:'bg-warning text-dark', HEARING_SCHEDULED:'bg-info text-dark', JUDGMENT_PENDING:'bg-danger', DISMISSED:'bg-secondary', SCHEDULED:'bg-primary', COMPLETED:'bg-success', ADJOURNED:'bg-warning text-dark', CANCELLED:'bg-danger', DRAFT:'bg-warning text-dark', FINAL:'bg-success' };
    return m[s] ?? 'bg-secondary';
  }
  verifyBadge(s: string): string {
    return s === 'VERIFIED' ? 'bg-success' : s === 'REJECTED' ? 'bg-danger' : 'bg-warning text-dark';
  }
}
