import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CaseApiService, CitizenApiService, UserApiService } from '../../core/services/api.service';
import { CitizenResponse, UserResponse } from '../../shared/models/models';

@Component({
  selector: 'app-case-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-header">
      <h4><i class="bi bi-folder-plus me-2"></i>File New Case</h4>
    </div>
    <div class="p-4">
      <div class="row justify-content-center">
        <div class="col-lg-7">
          <div class="card">
            <div class="card-body p-4">
              <div *ngIf="error" class="alert alert-danger">{{ error }}</div>
              <div *ngIf="success" class="alert alert-success">{{ success }}</div>
              <form (ngSubmit)="onSubmit()">
                <div class="mb-3">
                  <label class="form-label">Case Title <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" [(ngModel)]="form.title" name="title" required
                         placeholder="e.g. Property Dispute - John Doe">
                </div>
                <div class="mb-3">
                  <label class="form-label">Description</label>
                  <textarea class="form-control" rows="3" [(ngModel)]="form.description" name="description"
                            placeholder="Brief description of the case..."></textarea>
                </div>
                <div class="mb-3">
                  <label class="form-label">Citizen <span class="text-danger">*</span></label>
                  <select class="form-select" [(ngModel)]="form.citizenId" name="citizenId" required>
                    <option [value]="0">Select citizen...</option>
                    <option *ngFor="let c of citizens" [value]="c.citizenId">
                      {{ c.name }} (ID: {{ c.citizenId }})
                    </option>
                  </select>
                </div>
                <div class="mb-4">
                  <label class="form-label">Lawyer (Optional)</label>
                  <select class="form-select" [(ngModel)]="form.lawyerId" name="lawyerId">
                    <option [value]="undefined">No lawyer assigned</option>
                    <option *ngFor="let l of lawyers" [value]="l.userId">
                      {{ l.name }} ({{ l.email }})
                    </option>
                  </select>
                </div>
                <div class="d-flex gap-2">
                  <button type="submit" class="btn btn-primary" [disabled]="loading">
                    <span *ngIf="loading" class="spinner-border spinner-border-sm me-1"></span>
                    File Case
                  </button>
                  <a routerLink="/cases" class="btn btn-outline-secondary">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CaseFormComponent implements OnInit {
  form = { title: '', description: '', citizenId: 0, lawyerId: undefined as number | undefined };
  citizens: CitizenResponse[] = [];
  lawyers: UserResponse[] = [];
  loading = false;
  error = '';
  success = '';

  constructor(private api: CaseApiService, private citizenApi: CitizenApiService, private userApi: UserApiService, private router: Router) {}

  ngOnInit(): void {
    this.citizenApi.getAll().subscribe(d => this.citizens = d);
    this.userApi.getByRole('LAWYER').subscribe(d => this.lawyers = d);
  }

  onSubmit(): void {
    this.loading = true; this.error = '';
    const req = { ...this.form, lawyerId: this.form.lawyerId || undefined };
    this.api.file(req as any).subscribe({
      next: (c) => { this.success = `Case #${c.caseId} filed successfully!`; setTimeout(() => this.router.navigate(['/cases', c.caseId]), 1200); },
      error: (e) => { this.error = e.error?.message || 'Failed to file case'; this.loading = false; }
    });
  }
}
