import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NotificationApiService } from '../../core/services/api.service';
import { NotificationResponse } from '../../shared/models/models';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="page-header d-flex justify-content-between align-items-center">
      <h4><i class="bi bi-bell me-2"></i>Notifications</h4>
      <button class="btn btn-outline-secondary btn-sm" (click)="markAllRead()">Mark All Read</button>
    </div>
    <div class="p-4">
      <div *ngIf="loading" class="text-center py-5"><div class="spinner-border text-primary"></div></div>
      <div *ngIf="!loading">
        <div *ngFor="let n of notifications" class="card mb-2"
             [class.border-start]="n.status==='UNREAD'"
             [style.border-left-color]="n.status==='UNREAD'?'var(--js-secondary)':''"
             [style.border-left-width]="n.status==='UNREAD'?'4px':''">
          <div class="card-body py-3">
            <div class="d-flex justify-content-between align-items-start">
              <div class="d-flex gap-3">
                <div class="rounded-circle d-flex align-items-center justify-content-center"
                     [ngClass]="catBg(n.category)"
                     style="width:40px;height:40px;min-width:40px">
                  <i class="bi" [ngClass]="catIcon(n.category)"></i>
                </div>
                <div>
                  <div [class.fw-bold]="n.status==='UNREAD'">{{ n.message }}</div>
                  <small class="text-muted">{{ n.category }} · {{ n.createdDate | date:'medium' }}</small>
                </div>
              </div>
              <div class="d-flex align-items-center gap-2">
                <span *ngIf="n.status==='UNREAD'" class="badge bg-primary">New</span>
                <button *ngIf="n.status==='UNREAD'" class="btn btn-sm btn-outline-secondary" (click)="markRead(n)">
                  <i class="bi bi-check"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
        <div *ngIf="notifications.length===0" class="text-center text-muted py-5">
          <i class="bi bi-bell-slash" style="font-size:3rem"></i>
          <p class="mt-2">No notifications</p>
        </div>
      </div>
    </div>
  `
})
export class NotificationsComponent implements OnInit {
  notifications: NotificationResponse[] = [];
  loading = true;

  constructor(private api: NotificationApiService, private auth: AuthService) {}

  ngOnInit(): void {
    const userId = this.auth.currentUser?.userId;
    if (userId) {
      this.api.getByUser(userId).subscribe({
        next: d => { this.notifications = d; this.loading = false; },
        error: () => this.loading = false
      });
    } else { this.loading = false; }
  }

  markRead(n: NotificationResponse): void {
    this.api.markRead(n.notificationId).subscribe(updated => {
      this.notifications = this.notifications.map(x => x.notificationId === n.notificationId ? updated : x);
    });
  }

  markAllRead(): void {
    this.notifications.filter(n => n.status === 'UNREAD').forEach(n => this.markRead(n));
  }

  catBg(cat: string): string {
    const m: Record<string,string> = { CASE:'bg-primary text-white', HEARING:'bg-info text-dark', JUDGMENT:'bg-warning text-dark', COMPLIANCE:'bg-success text-white' };
    return m[cat] ?? 'bg-secondary text-white';
  }

  catIcon(cat: string): string {
    const m: Record<string,string> = { CASE:'bi-folder2-open', HEARING:'bi-calendar-event', JUDGMENT:'bi-hammer', COMPLIANCE:'bi-shield-check' };
    return m[cat] ?? 'bi-bell';
  }
}
