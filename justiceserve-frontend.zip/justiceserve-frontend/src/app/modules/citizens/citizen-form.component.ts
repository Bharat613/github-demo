import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CitizenApiService, UserApiService } from '../../core/services/api.service';
import { UserResponse } from '../../shared/models/models';

@Component({
  selector: 'app-citizen-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-header">
      <h4><i class="bi bi-person-plus me-2"></i>Register Citizen</h4>
    </div>
    <div class="p-4">
      <div class="row justify-content-center">
        <div class="col-lg-7">
          <div class="card">
            <div class="card-body p-4">
              <div *ngIf="error" class="alert alert-danger">{{ error }}</div>
              <div *ngIf="success" class="alert alert-success">{{ success }}</div>
              <form (ngSubmit)="onSubmit()">
                <div class="mb-3">
                  <label class="form-label">Link to User Account <span class="text-danger">*</span></label>
                  <select class="form-select" [(ngModel)]="form.userId" name="userId" required>
                    <option [value]="0">Select user...</option>
                    <option *ngFor="let u of users" [value]="u.userId">{{ u.name }} – {{ u.email }}</option>
                  </select>
                  <small class="text-muted">User must be registered first</small>
                </div>
                <div class="mb-3">
                  <label class="form-label">Full Name <span class="text-danger">*</span></label>
                  <input class="form-control" [(ngModel)]="form.name" name="name" required placeholder="John Doe">
                </div>
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" [(ngModel)]="form.dob" name="dob">
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Gender</label>
                    <select class="form-select" [(ngModel)]="form.gender" name="gender">
                      <option value="">Select...</option>
                      <option>Male</option><option>Female</option><option>Other</option>
                    </select>
                  </div>
                  <div class="col-12">
                    <label class="form-label">Address</label>
                    <textarea class="form-control" rows="2" [(ngModel)]="form.address" name="address" placeholder="123 Main St, City"></textarea>
                  </div>
                  <div class="col-12">
                    <label class="form-label">Contact Info</label>
                    <input class="form-control" [(ngModel)]="form.contactInfo" name="contactInfo" placeholder="+91 9999999999">
                  </div>
                </div>
                <div class="d-flex gap-2 mt-4">
                  <button type="submit" class="btn btn-primary" [disabled]="loading">
                    <span *ngIf="loading" class="spinner-border spinner-border-sm me-1"></span>Register
                  </button>
                  <a routerLink="/citizens" class="btn btn-outline-secondary">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CitizenFormComponent implements OnInit {
  form = { userId: 0, name: '', dob: '', gender: '', address: '', contactInfo: '' };
  users: UserResponse[] = [];
  loading = false;
  error = '';
  success = '';

  constructor(private api: CitizenApiService, private userApi: UserApiService, private router: Router) {}

  ngOnInit(): void {
    this.userApi.getAll().subscribe(d => this.users = d.filter(u => u.role === 'CITIZEN'));
  }

  onSubmit(): void {
    this.loading = true; this.error = '';
    this.api.create(this.form as any).subscribe({
      next: c => { this.success = `Citizen #${c.citizenId} registered!`; setTimeout(() => this.router.navigate(['/citizens', c.citizenId]), 1200); },
      error: e => { this.error = e.error?.message || 'Failed to register'; this.loading = false; }
    });
  }
}
