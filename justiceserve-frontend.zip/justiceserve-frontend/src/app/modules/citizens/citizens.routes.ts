import { Routes } from '@angular/router';

export const citizensRoutes: Routes = [
  { path: '', loadComponent: () => import('./citizens-list.component').then(m => m.CitizensListComponent) },
  { path: 'new', loadComponent: () => import('./citizen-form.component').then(m => m.CitizenFormComponent) },
  { path: ':id', loadComponent: () => import('./citizen-detail.component').then(m => m.CitizenDetailComponent) },
];
