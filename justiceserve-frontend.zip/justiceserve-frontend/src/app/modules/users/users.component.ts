import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserApiService } from '../../core/services/api.service';
import { UserResponse } from '../../shared/models/models';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="page-header d-flex justify-content-between align-items-center">
      <h4><i class="bi bi-person-gear me-2"></i>User Management</h4>
    </div>
    <div class="p-4">
      <!-- Filter -->
      <div class="card mb-3">
        <div class="card-body py-2 d-flex gap-2">
          <input class="form-control form-control-sm w-50" placeholder="Search by name or email..." [(ngModel)]="search">
          <select class="form-select form-select-sm" style="width:200px" [(ngModel)]="filterRole">
            <option value="">All Roles</option>
            <option *ngFor="let r of roles" [value]="r">{{ r }}</option>
          </select>
        </div>
      </div>

      <div class="card">
        <div class="card-body p-0">
          <div *ngIf="loading" class="text-center py-5"><div class="spinner-border text-primary"></div></div>
          <div class="table-responsive" *ngIf="!loading">
            <table class="table table-hover mb-0">
              <thead><tr>
                <th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Phone</th><th>Status</th><th>Actions</th>
              </tr></thead>
              <tbody>
                <tr *ngFor="let u of filtered">
                  <td>#{{ u.userId }}</td>
                  <td>
                    <div class="d-flex align-items-center gap-2">
                      <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center"
                           style="width:32px;height:32px;font-size:0.8rem;font-weight:700">
                        {{ u.name[0] }}
                      </div>
                      {{ u.name }}
                    </div>
                  </td>
                  <td>{{ u.email }}</td>
                  <td><span class="badge" [ngClass]="roleBadge(u.role)">{{ u.role }}</span></td>
                  <td>{{ u.phone || '—' }}</td>
                  <td>
                    <span class="badge" [ngClass]="u.status==='ACTIVE'?'bg-success':'bg-danger'">{{ u.status }}</span>
                  </td>
                  <td>
                    <button class="btn btn-sm btn-outline-warning me-1" (click)="toggleStatus(u)"
                            [title]="u.status==='ACTIVE'?'Deactivate':'Activate'">
                      <i class="bi" [ngClass]="u.status==='ACTIVE'?'bi-person-x':'bi-person-check'"></i>
                    </button>
                    <button class="btn btn-sm btn-outline-danger" (click)="deleteUser(u.userId)" title="Delete">
                      <i class="bi bi-trash"></i>
                    </button>
                  </td>
                </tr>
                <tr *ngIf="filtered.length===0">
                  <td colspan="7" class="text-center text-muted py-4">No users found</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class UsersComponent implements OnInit {
  users: UserResponse[] = [];
  loading = true;
  search = '';
  filterRole = '';
  roles = ['CITIZEN','LAWYER','JUDGE','CLERK','ADMIN','COMPLIANCE','AUDITOR'];

  constructor(private api: UserApiService) {}

  get filtered(): UserResponse[] {
    return this.users.filter(u =>
      (!this.filterRole || u.role === this.filterRole) &&
      (!this.search || u.name.toLowerCase().includes(this.search.toLowerCase()) || u.email.toLowerCase().includes(this.search.toLowerCase()))
    );
  }

  ngOnInit(): void {
    this.api.getAll().subscribe({ next: d => { this.users = d; this.loading = false; }, error: () => this.loading = false });
  }

  toggleStatus(u: UserResponse): void {
    const newStatus = u.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
    this.api.updateStatus(u.userId, newStatus).subscribe(updated => {
      this.users = this.users.map(x => x.userId === u.userId ? updated : x);
    });
  }

  deleteUser(id: number): void {
    if (!confirm('Delete this user?')) return;
    this.api.delete(id).subscribe(() => {
      this.users = this.users.filter(u => u.userId !== id);
    });
  }

  roleBadge(role: string): string {
    const m: Record<string,string> = { ADMIN:'bg-danger', JUDGE:'bg-primary', LAWYER:'bg-info text-dark', CLERK:'bg-warning text-dark', CITIZEN:'bg-secondary', COMPLIANCE:'bg-success', AUDITOR:'bg-dark' };
    return m[role] ?? 'bg-secondary';
  }
}
