import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { HearingApiService, CaseApiService, UserApiService } from '../../core/services/api.service';
import { CaseResponse, UserResponse } from '../../shared/models/models';

@Component({
  selector: 'app-hearing-form',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink],
  template: `
    <div class="page-header">
      <h4><i class="bi bi-calendar-plus me-2"></i>Schedule Hearing</h4>
    </div>
    <div class="p-4">
      <div class="row justify-content-center">
        <div class="col-lg-6">
          <div class="card">
            <div class="card-body p-4">
              <div *ngIf="error" class="alert alert-danger">{{ error }}</div>
              <div *ngIf="success" class="alert alert-success">{{ success }}</div>
              <form (ngSubmit)="onSubmit()">
                <div class="mb-3">
                  <label class="form-label">Case <span class="text-danger">*</span></label>
                  <select class="form-select" [(ngModel)]="form.caseId" name="caseId" required>
                    <option [value]="0">Select case...</option>
                    <option *ngFor="let c of cases" [value]="c.caseId">
                      #{{ c.caseId }} – {{ c.title }}
                    </option>
                  </select>
                </div>
                <div class="mb-3">
                  <label class="form-label">Judge <span class="text-danger">*</span></label>
                  <select class="form-select" [(ngModel)]="form.judgeId" name="judgeId" required>
                    <option [value]="0">Select judge...</option>
                    <option *ngFor="let j of judges" [value]="j.userId">{{ j.name }}</option>
                  </select>
                </div>
                <div class="row g-3">
                  <div class="col-md-6">
                    <label class="form-label">Date <span class="text-danger">*</span></label>
                    <input type="date" class="form-control" [(ngModel)]="form.date" name="date" required>
                  </div>
                  <div class="col-md-6">
                    <label class="form-label">Time <span class="text-danger">*</span></label>
                    <input type="time" class="form-control" [(ngModel)]="form.time" name="time" required>
                  </div>
                </div>
                <div class="d-flex gap-2 mt-4">
                  <button type="submit" class="btn btn-primary" [disabled]="loading">
                    <span *ngIf="loading" class="spinner-border spinner-border-sm me-1"></span>Schedule
                  </button>
                  <a routerLink="/hearings" class="btn btn-outline-secondary">Cancel</a>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class HearingFormComponent implements OnInit {
  form = { caseId: 0, judgeId: 0, date: '', time: '' };
  cases: CaseResponse[] = [];
  judges: UserResponse[] = [];
  loading = false;
  error = '';
  success = '';

  constructor(private api: HearingApiService, private caseApi: CaseApiService, private userApi: UserApiService, private router: Router) {}

  ngOnInit(): void {
    this.caseApi.getAll().subscribe(d => this.cases = d.filter(c => c.status !== 'CLOSED'));
    this.userApi.getByRole('JUDGE').subscribe(d => this.judges = d);
  }

  onSubmit(): void {
    this.loading = true; this.error = '';
    this.api.schedule(this.form as any).subscribe({
      next: h => { this.success = `Hearing #${h.hearingId} scheduled!`; setTimeout(() => this.router.navigate(['/hearings', h.hearingId]), 1200); },
      error: e => { this.error = e.error?.message || 'Failed to schedule'; this.loading = false; }
    });
  }
}
